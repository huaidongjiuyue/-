#define __DL1A_H
#ifndef __DL1A_H
#include "headfile.h"


extern uint8 dl1a_finsh_flag;
extern uint16 dl1a_distance_mm;
void dl1a_scan(void);

#endif
