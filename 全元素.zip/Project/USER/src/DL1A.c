#include "headfile.h"

//uint8 dl1a_finsh_flag = 0;
//uint16 dl1a_distance_mm;
//���
void dl1a_scan(void)
{
	
	if(dl1a_distance_mm <= 700)
	{
		dl1a_finsh_flag = 1;
		delay_ms(500);
		dl1a_finsh_flag = 0;
	}
	
}
