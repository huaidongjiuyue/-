#ifndef _element_H
#define _element_H

sbit Buzz = P6^7;
sbit Hall = P2^6;
sbit Ce = P6^5;
extern uint32 Tcount;
extern uint8 Ce_flag;  						//����־λ
extern uint8 hall_flag;		 					//����־λ
extern uint8 RU_flag; 
extern uint16 Hall_Num;
extern uint8 Chu; 
extern uint16 adc_buf[4];
extern uint8 AD_flag;
extern uint8 cishu;
extern uint8 baohu;


void element (void);


#endif