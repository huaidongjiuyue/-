#ifndef _MOTOR_H_
#define _MOTOR_H_


void control(void);
void motor_speed(int16 speed);
int FLAG(int16 num);
void display(void);
int myabs(int16 a);
void BUZZ_ON(void);


#endif
