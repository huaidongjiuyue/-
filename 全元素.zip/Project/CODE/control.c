#include "headfile.h"
//ѭ������
void control(void)
{
//****************����ѭ��***************//
 if(ALL_SUM>=10&&Ce_flag==0&&hall_flag==0&&RU_flag==0&&Chu==0)
	{
		left_motor_pid(Goal_speed1);     //60�ٶ�
    right_motor_pid(Goal_speed2);
	}
	//�����������
	if(ALL_SUM<10&&Ce_flag==0&&hall_flag==0&&Chu==0)//&&RU_flag==0)//&&hall_flag==0&&Ce_flag == 0)//&&Help_flag==0&& House_Start==0)  
	{
		left_motor_pid(0);     //60�ٶ�
    right_motor_pid(0);

	}
}


void motor_speed(int16 speed)
{
	left_motor_pid(speed);
  right_motor_pid(speed);
}

//oled��Ļ��ʾ��������Ҫʲô�����Լ�д
void display(void)
{
    oled_p6x8str(0,1,"L_E");
	  oled_int16(4*6,1,Goal_speed1);
	
		oled_p6x8str(0,2,"R_e");	
		oled_int16(4*6,2,Goal_speed2);

	
	  oled_p6x8str(0,3,"L");
	  oled_uint16(4*6,3,adc_buf[0]);
	  oled_p6x8str(56,3,"L_X");	
		oled_uint16(11*8,3,adc_buf[2]);
	
		oled_p6x8str(0,4,"R");	
		oled_uint16(4*6,4,adc_buf[1]);
	  oled_p6x8str(56,4,"R_X");	
		oled_uint16(11*8,4,adc_buf[3]);

	  oled_p6x8str(0,5,"AD_flag");   
	  oled_int16(10*8,5,AD_flag);

	  oled_p6x8str(0,6,"RU_flag");
	  oled_int16(10*8,6,RU_flag);

		
		oled_p6x8str(0,7,"Ce_flag");	
		oled_uint16(10*6,7,Ce_flag);
	
}
//����ֵ����
int myabs(int16 a)
{ 		   
	  int temp;
		if(a<0)  temp=-a;  
	  else temp=a;
	  return temp;
}

