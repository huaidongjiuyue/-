#ifndef _KEY_H
#define _KEY_H

#define CIRCLE_OUT_CLOSE 0
#define CIRCLE_OUT_OPEN	 1

extern uint8 circle_out_mode ;

#include "headfile.h"

//���尴������
#define KEY1_PIN    P70
#define KEY2_PIN    P71
#define KEY3_PIN    P72
#define KEY4_PIN    P73
//���岦�뿪������
#define SW1_PIN     P75
#define SW2_PIN     P76
#define SW3_PIN     P67
#define SW4_PIN     P70


//���뿪��״̬����
extern uint8 sw1_status;
extern uint8 sw2_status;

//����״̬����
extern uint8 key1_status ;
extern uint8 key2_status ;
extern uint8 key3_status ;
extern uint8 key4_status ;

//��һ�ο���״̬����
extern uint8 key1_last_status;
extern uint8 key2_last_status;
extern uint8 key3_last_status;
extern uint8 key4_last_status;

//���ر�־λ
extern uint8 key1_flag;
extern uint8 key2_flag;
extern uint8 key3_flag;
extern uint8 key4_flag;
extern uint8 oled_fill_flag;
extern uint8 chu_flag;
extern uint8 sw1_last_status;
extern uint8 sw2_last_status;

extern uint8 test1,test2,test3,test4;

void key(void);


#endif
